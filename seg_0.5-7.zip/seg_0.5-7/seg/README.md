# seg
R package 'seg' for measuring and visualising population segregation
